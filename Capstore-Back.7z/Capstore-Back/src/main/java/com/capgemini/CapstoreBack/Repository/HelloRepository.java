package com.capgemini.CapstoreBack.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class HelloRepository implements IHelloRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
}
