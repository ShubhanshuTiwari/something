package com.capgemini.CapstoreBack.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.CapstoreBack.bean.Product;
import com.capgemini.CapstoreBack.service.IProductService;

@RestController
public class ProductRestController {

	@Autowired
	IProductService productService;
	
	@RequestMapping(value="/capstore")
	public List<Product> getProduct(){
		System.out.println("hi");
		System.out.println(productService.getProduct());
		return productService.getProduct();
	}
	
}
