package com.capgemini.CapstoreBack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.CapstoreBack.Repository.IHelloRepository;
@Transactional
@Service
public class HelloService implements IHelloService {
	
	@Autowired
	IHelloRepository helloRepo;
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return helloRepo.getMessage();
	}

}
