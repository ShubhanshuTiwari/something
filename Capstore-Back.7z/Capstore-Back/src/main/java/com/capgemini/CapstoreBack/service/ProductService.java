package com.capgemini.CapstoreBack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CapstoreBack.Repository.IProductRepository;
import com.capgemini.CapstoreBack.bean.Product;
@Service
public class ProductService implements IProductService{

	@Autowired
	IProductRepository prodRepo;
	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return prodRepo.getProduct();
	}

}
