package com.capgemini.CapstoreBack.service;

public interface IHelloService {

	public String getMessage();
}
