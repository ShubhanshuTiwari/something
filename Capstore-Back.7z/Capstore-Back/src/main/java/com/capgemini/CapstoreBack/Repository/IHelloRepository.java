package com.capgemini.CapstoreBack.Repository;

public interface IHelloRepository {

	public String getMessage();
}
