package com.capgemini.CapstoreBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration

@EntityScan("com.capgemini.CapstoreBack.bean")
@ComponentScan("com.capgemini.CapstoreBack.bean")
@ComponentScan("com.capgemini.CapstoreBack.Repository")
@ComponentScan("com.capgemini.CapstoreBack.RestController")
@ComponentScan("com.capgemini.CapstoreBack.service")
public class CapstoreBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoreBackApplication.class, args);
	}

}
