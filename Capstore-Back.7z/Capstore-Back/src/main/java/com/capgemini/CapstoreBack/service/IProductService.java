package com.capgemini.CapstoreBack.service;

import java.util.List;

import com.capgemini.CapstoreBack.bean.Product;



public interface IProductService {

	public List<Product> getProduct();
	
}
