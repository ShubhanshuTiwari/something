package com.capgemini.CapstoreBack.bean;

public enum SoftDelete {
	Activated, Deactivated
}
