package PageBin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferencePageFactory {
	WebDriver driver;

	public ConferencePageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement firstname;
		
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement contactno;
	
	@FindBy(name="size")
	@CacheLookup
	WebElement noOfPeoples;
	
	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement building;
	
	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement area;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement state;

	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td[2]/input")
	@CacheLookup
	WebElement memberStatus;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement nextBtn;
	
//	Getters

	public WebElement getFirstname() {
		return firstname;
	}

	public WebElement getLastname() {
		return lastname;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getContactno() {
		return contactno;
	}

	public WebElement getNoOfPeoples() {
		return noOfPeoples;
	}

	public WebElement getBuilding() {
		return building;
	}

	public WebElement getArea() {
		return area;
	}

	public WebElement getCity() {
		return city;
	}

	public WebElement getState() {
		return state;
	}

	public WebElement getMemberStatus() {
		return memberStatus;
	}

	public WebElement getNextBtn() {
		return nextBtn;
	}
	
	
//	Setters

	public void setFirstname(String sfirstname) {
		firstname.sendKeys(sfirstname);
	}

	public void setLastname(String slastname) {
		lastname.sendKeys(slastname); 
	}

	public void setEmail(String semail) {
		email.sendKeys(semail);
	}

	public void setContactno(String scontactno) {
		contactno.sendKeys(scontactno);
	}

	public void setNoOfPeoples(String sNoOfPeoples) {
		Select drpPerson = new Select(noOfPeoples);
		noOfPeoples.sendKeys(sNoOfPeoples);
	}

	public void setBuilding(String sbuilding) {
		building.sendKeys(sbuilding);
	}

	public void setArea(String sarea) {
		area.sendKeys(sarea);
	}

	public void setCity(String scity) {
		Select drpCity = new Select(city);
		city.sendKeys(scity);
	}

	public void setState(String sstate) {
		Select drpState = new Select(state);
		state.sendKeys(sstate);
	}

	public void setMemberStatus() {
		memberStatus.click();
	}

	public void setNextBtn() {
		nextBtn.click();
	}
	
}
