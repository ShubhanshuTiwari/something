package PageBin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageFactory {
	WebDriver driver;

	public PaymentPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardHoldername;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitCardNo;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expMonth;

	@FindBy(id="txtYear")
	@CacheLookup
	WebElement expYear;

	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement paymentbtn;
	
//	Getters

	public WebElement getCardHoldername() {
		return cardHoldername;
	}

	public WebElement getDebitCardNo() {
		return debitCardNo;
	}

	public WebElement getCvv() {
		return cvv;
	}

	public WebElement getExpMonth() {
		return expMonth;
	}

	public WebElement getExpYear() {
		return expYear;
	}
	
	public WebElement getPaymentbtn() {
		return paymentbtn;
	}
//	Setters

	public void setCardHoldername(String scardHoldername) {
		cardHoldername.sendKeys(scardHoldername);
	}

	public void setDebitCardNo(String sdebitCardNo) {
		debitCardNo.sendKeys(sdebitCardNo);
	}

	public void setCvv(String scvv) {
		cvv.sendKeys(scvv);
	}

	public void setExpMonth(String sexpMonth) {
		expMonth.sendKeys(sexpMonth);
	}

	public void setExpYear(String sexpYear) {
		expYear.sendKeys(sexpYear);
	}
	
	public void setPaymentbtn() {
		paymentbtn.click();
	}
	
}
