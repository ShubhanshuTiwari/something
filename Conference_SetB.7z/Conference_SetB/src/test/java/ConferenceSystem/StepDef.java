package ConferenceSystem;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.ConferencePageFactory;
import PageBin.PaymentPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	WebDriver driver;
	ConferencePageFactory objConf;
	PaymentPageFactory objPymt;

	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		String projectLoc = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLoc + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objConf = new ConferencePageFactory(driver);
		driver.get(projectLoc + "\\lib\\views\\ConferenceRegistartion.html");
	}

	@Then("^Check the title of the registration page$")
	public void check_the_title_of_the_registration_page() throws Throwable {
		String title = driver.getTitle();
		if (title.contentEquals("Conference Registartion")) {
			System.out.println("****Title Matched****");
		} else {
			System.out.println("****Title Not Mached****");
		}
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^User leaves the first name empty$")
	public void user_leaves_the_first_name_empty() throws Throwable {
		objConf.setFirstname("");
		Thread.sleep(100);
	}

	@When("^clicks Next button$")
	public void clicks_Next_button() throws Throwable {
		objConf.setNextBtn();
		Thread.sleep(100);
	}

	@Then("^Shows the alert message$")
	public void shows_the_alert_message() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String alertMsg = alert.getText();
		Thread.sleep(500);
		System.out.println("****" + alertMsg + "****");
		alert.accept();
		driver.close();
	}

	@When("^User leaves the last name empty$")
	public void user_leaves_the_last_name_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("");
		Thread.sleep(100);
	}

	@When("^User leaves the email empty$")
	public void user_leaves_the_email_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("");
		Thread.sleep(100);
	}

	@When("^User leaves the contact no empty$")
	public void user_leaves_the_contact_no_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("st@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("");
		Thread.sleep(100);
	}

	@When("^User enters the invalid contact$")
	public void user_enters_the_invalid_contact() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("st@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("1245789621");
		Thread.sleep(100);
	}

	@When("^User leaves the no of people attending empty$")
	public void user_leaves_the_no_of_people_attending_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);

	}

	@When("^User leaves the building and room no empty$")
	public void user_leaves_the_building_and_room_no_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);
		objConf.setBuilding("");
		Thread.sleep(100);
	}

	@When("^User leaves the area name empty$")
	public void user_leaves_the_area_name_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(100);
		objConf.setArea("");
		Thread.sleep(100);
	}

	@When("^User leaves the city empty$")
	public void user_leaves_the_city_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(100);
		objConf.setArea("Near MIDC Park");
		Thread.sleep(100);
		objConf.setCity("");
		Thread.sleep(100);
	}

	@When("^User leaves the state empty$")
	public void user_leaves_the_state_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(100);
		objConf.setArea("Talwade");
		Thread.sleep(100);
		objConf.setCity("Pune");
		Thread.sleep(100);
		objConf.setState("");
		Thread.sleep(100);
	}

	@When("^User leaves the membership type empty$")
	public void user_leaves_the_membership_type_empty() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(100);
		objConf.setArea("Talwade");
		Thread.sleep(100);
		objConf.setCity("Pune");
		Thread.sleep(100);
		objConf.setState("Maharashtra");
		Thread.sleep(100);
	}

	@When("^User gives all valid data$")
	public void user_gives_all_valid_data() throws Throwable {
		objConf.setFirstname("Shubhanshu");
		Thread.sleep(100);
		objConf.setLastname("Tiwari");
		Thread.sleep(100);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(100);
		objConf.setContactno("7599246005");
		Thread.sleep(100);
		objConf.setNoOfPeoples("2");
		Thread.sleep(100);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(100);
		objConf.setArea("Talwade");
		Thread.sleep(100);
		objConf.setCity("Pune");
		Thread.sleep(100);
		objConf.setState("Maharashtra");
		Thread.sleep(100);
		objConf.setMemberStatus();
		Thread.sleep(100);
	}

	@Then("^Shows the alert message and navigate to payment page$")
	public void shows_the_alert_message_and_navigate_to_payment_page() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String alertMsg = alert.getText();
		Thread.sleep(500);
		System.out.println("****" + alertMsg + "****");
		alert.accept();
		driver.close();
	}

	@Given("^User is on payment page$")
	public void user_is_on_payment_page() throws Throwable {
		String projectLoc = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLoc + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objPymt = new PaymentPageFactory(driver);
		driver.get(projectLoc + "\\lib\\views\\PaymentDetails.html");
	}

	@Then("^Check the title of the payment page$")
	public void check_the_title_of_the_payment_page() throws Throwable {
		String title = driver.getTitle();
		if (title.contentEquals("Payment Details")) {
			System.out.println("****Title Matched****");
		} else {
			System.out.println("****Title Not Mached****");
		}
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^User leaves the card holder name empty$")
	public void user_leaves_the_card_holder_name_empty() throws Throwable {
		objPymt.setCardHoldername("");
		Thread.sleep(100);
	}

	@When("^clicks make payment button$")
	public void clicks_make_payment_button() throws Throwable {
		objPymt.setPaymentbtn();
	}

	@When("^User leaves the debit card no empty$")
	public void user_leaves_the_debit_card_no_empty() throws Throwable {
		objPymt.setCardHoldername("Shubham Kumar");
		objPymt.setDebitCardNo("");
	}

	@When("^User leaves the cvv empty$")
	public void user_leaves_the_cvv_empty() throws Throwable {
		objPymt.setCardHoldername("Shubhanshu");
		objPymt.setDebitCardNo("4567894578459658");
		objPymt.setCvv("");
	}

	@When("^User leaves the expiration month empty$")
	public void user_leaves_the_expiration_month_empty() throws Throwable {
		objPymt.setCardHoldername("Shubhanshu");
		objPymt.setDebitCardNo("4567894578459658");
		objPymt.setCvv("786");
		objPymt.setExpMonth("");
	}

	@When("^User leaves the expiration year empty$")
	public void user_leaves_the_expiration_year_empty() throws Throwable {
		objPymt.setCardHoldername("Shubhanshu");
		 objPymt.setDebitCardNo("4567894578459658");
		 objPymt.setCvv("786"); 
		 
	}

	@When("^User gives all the valid data$")
	public void user_gives_all_the_valid_data() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		
	}
}
