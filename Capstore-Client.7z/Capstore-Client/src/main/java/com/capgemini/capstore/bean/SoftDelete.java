package com.capgemini.capstore.bean;

public enum SoftDelete {
	Activated, Deactivated
}
