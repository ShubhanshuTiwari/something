package com.capgemini.capstore.bean;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
