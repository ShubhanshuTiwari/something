package com.capgemini.capstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.bean.HelloBean;
import com.capgemini.capstore.bean.Response;


@Controller
public class HelloController {
	

	

	
	@RequestMapping(value="/hello")
	public String getHello() {
		RestTemplate restTemplate = new RestTemplate(); 
		Response[] response = restTemplate.getForObject("http://localhost:9999/helloback",Response[].class);
		System.out.println(response);
		return "Hello";
	
	}
}
