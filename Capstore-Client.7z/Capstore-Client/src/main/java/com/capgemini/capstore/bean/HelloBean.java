package com.capgemini.capstore.bean;


public class HelloBean {

	@Override
	public String toString() {
		return "HelloBean [msg=" + msg + "]";
	}

	String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public HelloBean() {
	}

	public HelloBean(String msg) {
		this.msg = msg;
	}
	
	
	
}
