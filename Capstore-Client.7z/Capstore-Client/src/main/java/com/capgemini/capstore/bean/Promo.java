package com.capgemini.capstore.bean;

import java.util.Date;

public class Promo {

	private String promoCode;
	private double discountOffered;

	private Date promoValidity;

	private SoftDelete softDelete;

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public double getDiscountOffered() {
		return discountOffered;
	}

	public void setDiscountOffered(double discountOffered) {
		this.discountOffered = discountOffered;
	}

	public Date getPromoValidity() {
		return promoValidity;
	}

	public void setPromoValidity(Date promoValidity) {
		this.promoValidity = promoValidity;
	}

	public SoftDelete getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(SoftDelete softDelete) {
		this.softDelete = softDelete;
	}

}
